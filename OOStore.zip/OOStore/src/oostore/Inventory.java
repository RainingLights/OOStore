/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oostore;
import java.util.Scanner;
/**
 *
 * @author maxca
 */
public class Inventory{

    @Override
    public String toString() {
        return "Inventory{" + "storeInventoryArray=" + storeInventoryArray + '}';
    }

    public Item[] getStoreInventoryArray() {
        return storeInventoryArray;
    }
    
//make array of items Somewhere, probably as a public field instead of this but whatever 
    private Item[] cartArray;
    private Item[] storeInventoryArray = new Item[20];
    private int itemAmount;     // total number of items in the cart
    private double totalPrice;  // total price of items in the cart
    private int cartItemTotal;  // current cart capacity
    
    //elements of Item object
    public String itemName;
    public double itemPrice;
    public int itemStock;
     
    public Item[] populateInventory() {  //Add inventory items to the store
        
        //Edible items
        storeInventoryArray[0] = new Item("Apple", 1.00, 15);
        storeInventoryArray[1] = new Item("Orange", 1.00, 27);
        storeInventoryArray[2] = new Item("Pear", 1.25, 20);
        storeInventoryArray[3] = new Item("Salsa", 3.50 ,7);
        storeInventoryArray[4] = new Item("Water", 1.10, 25);
        storeInventoryArray[5] = new Item("Soda", 1.35, 18);
        storeInventoryArray[6] = new Item("Candy", 1.15, 9);
        storeInventoryArray[7] = new Item("Chips", 0.99, 11);
        storeInventoryArray[8] = new Item("Energy Drink", 2.00, 13);
        storeInventoryArray[9] = new Item("Cereal", 4.75, 10);
        
        //Non-edible items
        storeInventoryArray[10] = new Item("Paper Towels", 4.50, 35);
        storeInventoryArray[11] = new Item("Paper Plates", 2.35, 14);
        storeInventoryArray[12] = new Item("Plastic Cutlery", 2.50, 17);
        storeInventoryArray[13] = new Item("Sports Water Bottle", 5.00, 18);
        storeInventoryArray[14] = new Item("Shampoo", 5.65, 12);
        storeInventoryArray[15] = new Item("Soap", 1.50, 21);
        storeInventoryArray[16] = new Item("Bugspray", 3.45, 9);
        storeInventoryArray[17] = new Item("Pain Medicine", 6.65, 19);
        storeInventoryArray[18] = new Item("Baby Wipes", 5.45, 0);
        storeInventoryArray[19] = new Item("Newspaper", 1.00, 3);
        
        return storeInventoryArray;
    }

    public Item[] getCartArray() {
        return cartArray;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public void setItemStock(int itemStock) {
        this.itemStock = itemStock;
    }
    
    public void shoppingCart() {
        cartItemTotal = 3;
        cartArray = new Item[cartItemTotal];
        itemAmount = 0;
        totalPrice = 0.0;
    }
    
    public void addItem(String itemName, double price, int quantity) {
        this.itemName = itemName;
        this.itemPrice = price;
        this.itemStock = quantity;
        
        Scanner scan = new Scanner(System.in);
        String customerInput = scan.nextLine();
        //if (customerInput.equals()
        
        Item temp = new Item(itemName, price, quantity);
        totalPrice += (price * quantity);
        itemAmount += quantity;
        cartArray[itemAmount] = temp;
        if(itemAmount == cartItemTotal)
        {
            increaseSize();
        }
    }

    public void increaseSize() {
        Item[] temp = new Item[cartItemTotal+3];
        for(int i=0; i < cartItemTotal; i++)
        {
            temp[i] = cartArray[i];
        }
        cartArray = temp; 
        temp = null;
        cartItemTotal = cartArray.length;
    }
    
    /* public String getItemName(){
        return this.itemName;
    }
    
    public double getItemPrice(){
        return this.itemPrice;
    }
    
    public int getItemStock(){
        return this.itemStock;
    } */
    
    public Item getItem(int index){
        return cartArray[index];
    }
    
    /* public Item[] getInventory(){
        return storeInventoryArray;
    } */
    
    public String getList(){
        Item tempItem = new Item("none", 0.0, 0);
        //have some Inventory object made somewhere for this
        for(int i = 0; i < cartArray.length; i++){
            tempItem = getItem(i);
        }
        return tempItem.toString();
    }
    public Item[] viewCart(){
        return cartArray;
    }
}

