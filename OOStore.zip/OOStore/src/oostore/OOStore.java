/*
 * This application was created for the purpose of UNCC's ITCS 3112
 * Design and Implementation of Object-Oriented Systems.
 * Please do not copy or redistribute.
 */
package oostore;
/**
 *
 * @author maxca
 */
public class OOStore {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(" __     __     ______     __         ______     ______     __    __     ______        ______     __  __     ______     ______   ______     __    __     ______     ______    \n" +
            "/\\ \\  _ \\ \\   /\\  ___\\   /\\ \\       /\\  ___\\   /\\  __ \\   /\\ \"-./  \\   /\\  ___\\      /\\  ___\\   /\\ \\/\\ \\   /\\  ___\\   /\\__  _\\ /\\  __ \\   /\\ \"-./  \\   /\\  ___\\   /\\  == \\   \n" +
            "\\ \\ \\/ \".\\ \\  \\ \\  __\\   \\ \\ \\____  \\ \\ \\____  \\ \\ \\/\\ \\  \\ \\ \\-./\\ \\  \\ \\  __\\      \\ \\ \\____  \\ \\ \\_\\ \\  \\ \\___  \\  \\/_/\\ \\/ \\ \\ \\/\\ \\  \\ \\ \\-./\\ \\  \\ \\  __\\   \\ \\  __<   \n" +
            " \\ \\__/\".~\\_\\  \\ \\_____\\  \\ \\_____\\  \\ \\_____\\  \\ \\_____\\  \\ \\_\\ \\ \\_\\  \\ \\_____\\     \\ \\_____\\  \\ \\_____\\  \\/\\_____\\    \\ \\_\\  \\ \\_____\\  \\ \\_\\ \\ \\_\\  \\ \\_____\\  \\ \\_\\ \\_\\ \n" +
            "  \\/_/   \\/_/   \\/_____/   \\/_____/   \\/_____/   \\/_____/   \\/_/  \\/_/   \\/_____/      \\/_____/   \\/_____/   \\/_____/     \\/_/   \\/_____/   \\/_/  \\/_/   \\/_____/   \\/_/ /_/ \n" +
            "                                                                                                                                                                             ");
        System.out.println("Hello [user], please log in below:\nType \"Exit\" to exit.\n");
        customerLogin newLogin = new customerLogin();
        newLogin.loginScreen();
        
        /*LOGIN INFORMATION: 
            Standard customer: 
                Username: customer1
                Password: 1234
            Store admin:
                Username: admin
                Password: adminPass
        */
    }
    
    
    
}
