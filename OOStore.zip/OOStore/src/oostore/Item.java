/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oostore;

/**
 *
 * @author maxca
 */
public class Item {
    private String itemName;
    private double price;
    private int stock;
    Item(String itemName, double price, int stock) {
        this.itemName = itemName;
        this.price = price;
        this.stock = stock;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
    @Override
    public String toString() {
        String s = this.itemName;
        s = s + this.stock + "\n";
        return s;
    }
    
    public String getItemName() {
        return this.itemName;
    }
    
    public double getPrice() {
        return this.price;
    }
            
    public int getStock() {
        return this.stock;
    }
    
}
