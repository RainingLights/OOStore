package oostore;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author maxca
 */
public class customerLogin {
    private final ArrayList<Item> customerCartArray = new ArrayList<>();
    private final ArrayList<Item> adminCartArray = new ArrayList<>();
    private final Inventory displayedInventory = new Inventory();
    private final Item[] customerStoreInventory = displayedInventory.populateInventory();
    private final Item[] adminStoreInventory = displayedInventory.populateInventory();
    
    
    static boolean loginSuccess = false;
    //prompts user for username and password for store login
    public void loginScreen() {
        Scanner input = new Scanner(System.in);

    //Stores user and password string
        String user = "";
        String pass = "";
        boolean userQuit = false;
        
        if (!userQuit) {
            System.out.print("Username: ");
            user = input.nextLine();
            if (user.equalsIgnoreCase("exit")) {
                System.out.println("Have a nice day!");
                userQuit = true;
                loginSuccess = false;
            }
        }
        
        if (!userQuit) {
            System.out.print("Password: ");
            pass = input.nextLine();
            if (pass.equalsIgnoreCase("exit")) {
                System.out.println("Have a nice day!");
                //userQuit = true;
                loginSuccess = false;
            }
        }
        
    //prompts user to input a user and pass
        while (!loginSuccess) {
            
            if(user.equals("admin") && (pass.equals("adminPass"))) {
                System.out.println("\nWelcome, admin");
                loginSuccess = true;
                mainAdminScreen();
            } else if(user.equals("customer1") && (pass.equals("1234"))) { 
                System.out.println("\nWelcome, customer1");
                loginSuccess = true;
                mainCustomerScreen();
            } else {
                System.out.println("\nUsername or password not recognized, please try again.");
                loginScreen();
            }
        }
    }
    
    //If login credentials are provided for the "admin" user, this method will be run
    public void mainAdminScreen() {
        Scanner adminResponse = new Scanner(System.in);
        Inventory adminCart = new Inventory();
        adminCart.populateInventory();
        String userResponse;
        int userNumericResponse;
        
        if (loginSuccess) {
            boolean repeat = true;
            while (repeat) {
            System.out.println("What would you like to do?\n\n[Display stock]\n(\"display\", \"display inventory\")\n\n[Change stock]\n(\"Change stock\", \"stock\")\n\n[Change item name]\n(\"item name\", \"name\")\n\n[Exit]");
            userResponse = adminResponse.nextLine();
            
            switch (userResponse){
                
                case "Display inventory":
                case "display inventory":
                case "display":
                case "inventory":
                    
                    do {
                        System.out.println("Displaying current inventory. Input \"back\" to return:\n");
                            for (Item x : adminStoreInventory) {
                                System.out.println("Name: " + x.getItemName() + " | Price: " + x.getPrice() + " | Stock: " + x.getStock());
                            }
                        userResponse = adminResponse.nextLine();
                        
                        if (userResponse.equalsIgnoreCase("back")) {
                            System.out.println("Going back to menu...");
                            mainAdminScreen();
                        }
                        
                        
                    } while (!userResponse.equals("exit"));
                        System.exit(0);
                        
                case "Change stock":
                case "change stock":
                case "Stock":
                case "stock":
                    
                    do  {
                        System.out.println("Please input the name of the item you'd like to edit the stock of, or input \"back\" to return:\n");
                        userResponse = adminResponse.nextLine();
                        
                        if (userResponse.equalsIgnoreCase("back")) {
                            System.out.println("Going back to menu...");
                            mainAdminScreen();
                        }
                    
                        boolean foundItem = false;
                        int adminStockResponse;
                        for (Item x : adminStoreInventory) {
                            if (x.getItemName().equalsIgnoreCase(userResponse)) {
                                System.out.println("Found Item! \nPrice: " + x.getPrice() + "\nStock: " + x.getStock());
                                System.out.println("Edit stock of " + x.getItemName() + " to: ");
                                
                                if (adminResponse.hasNextInt()) {
                                    userNumericResponse = adminResponse.nextInt();
                                    x.setStock(userNumericResponse);
                                    System.out.println("Stock of " + x.getItemName() + " successfuly set.");
                                } else {
                                    System.out.println("Error: response is not an integer.");
                                }  
                            } else if (!foundItem && !userResponse.equals("")) {
                                System.out.println("Item not found or exit detected.");
                            }
                                foundItem = true;
                                break;
                        }
                        
                    } while (!userResponse.equals("exit"));
                        System.exit(0);
                        
                case "item name":
                case "Item name":
                case "Item Name":
                case "Name":
                case "name":
                    do  {
                        System.out.println("Please input the name of the item you'd like to edit the name of, or input \"back\" to return:\n");
                        userResponse = adminResponse.nextLine();
                        
                        if (userResponse.equalsIgnoreCase("back")) {
                            System.out.println("Going back to menu...");
                            mainAdminScreen();
                        }
                    
                        boolean foundItem = false;
                        for (Item x : adminStoreInventory) {
                            if (x.getItemName().equalsIgnoreCase(userResponse)) {
                                System.out.println("Found Item! \nPrice: " + x.getPrice() + "\nStock: " + x.getStock());
                                System.out.println("Edit name of " + x.getItemName() + " to: ");
                                userResponse = adminResponse.nextLine();
                                System.out.println("Name of " + x.getItemName() + " set to " + userResponse);
                                x.setItemName(userResponse);
                            }
                                foundItem = true;
                                break;
                        }
                        if (!foundItem && !userResponse.equals("")) 
                            System.out.println("Item not found or exit detected.");
                        
                    } while (!userResponse.equals("exit"));
                        System.exit(0);
                        
                case "exit":
                case "Exit":
                case "EXIT":
                    System.out.println("Have a nice day!");
                    System.exit(0);
                    
                default: 
                    System.out.println("Invalid response: Please specify one of the above options or type \'exit\'");
                    repeat = true;
                    break;
            }
        }
        }
    }
    
    //If login credentials are provided for the "customer1" user, this method will be run
    public void mainCustomerScreen() {
        Scanner customerResponse = new Scanner(System.in);
        Inventory customerCart = new Inventory();
        customerCart.populateInventory();
        String userResponse;
        int userNumericResponse;
        
        if (loginSuccess) {
            boolean repeat = true;
            while (repeat) {
            System.out.println("What would you like to do?\n\n[Display stock]\n(\"display\", \"display inventory\")\n\n[Add items]\n(\"add\", \"add items\")\n\n[Remove items]\n(\"remove\", \"remove items\")\n\n[View cart]\n(\"view\", \"cart\", \"view cart\")\n\n[Checkout]\n(\"checkout\")\n\n[Exit]");
            userResponse = customerResponse.nextLine();
            
            switch (userResponse){
                
                case "Display inventory":
                case "display inventory":
                case "display":
                case "inventory":
                    
                    do {
                        System.out.println("Displaying current inventory. Input \"back\" to return:\n");
                            for (Item x : adminStoreInventory) {
                                System.out.println("Name: " + x.getItemName() + " | Price: " + x.getPrice() + " | Stock: " + x.getStock());
                            }
                        userResponse = customerResponse.nextLine();
                        
                        if (userResponse.equalsIgnoreCase("back")) {
                            System.out.println("Going back to menu...");
                            mainAdminScreen();
                        }
                        
                        
                    } while (!userResponse.equals("exit"));
                        System.exit(0);
                
                case "add items":
                case "add":
                    
                    do  {
                        System.out.println("Please input the name of the item you'd like to add, or input \"back\" to return:\n");
                        userResponse = customerResponse.nextLine();
                        
                        if (userResponse.equalsIgnoreCase("back")) {
                            System.out.println("Going back to menu...");
                            //repeat = true;
                            mainCustomerScreen();
                            //break;
                        }
                    
                        boolean foundItem = false;
                        for (Item x : customerStoreInventory) {
                            if (x.getItemName().equalsIgnoreCase(userResponse)) {
                                System.out.println("Found Item! \nPrice: " + x.getPrice() + "\nStock: " + x.getStock());
                                System.out.println("How many " + x.getItemName() + "s would you like to add?");
                                if (customerResponse.hasNextInt()){
                                    userNumericResponse = customerResponse.nextInt();
                                    if (userNumericResponse <= x.getStock()) {
                                    for (int i = 0; i < userNumericResponse; i++) {
                                        customerCartArray.add(x);
                                        System.out.println(userNumericResponse + x.getItemName() +"(s) added to cart.");
                                    }
                                        } else {
                                        System.out.println("Error: Amount requested is greater than current stock.");
                                        mainCustomerScreen();
                                        }
                                } else {
                                    System.out.println("Error: response is not an integer."); 
                                }
                                
                                //if the user inputs a number less than or equal to total stock, add item(s) to the cart.
                                foundItem = true;

                                //view customer cart
                                System.out.println("-------------------------------------------------------------------------------\n" 
                                    + "Current user cart:");
                                for (int i = 0; i < customerCartArray.size(); i++) {
                                    System.out.println(customerCartArray.get(i).getItemName());
                                }
                                break;
                            }
                        }
                        if (!foundItem && !userResponse.equals("")) 
                            System.out.println("Item not found or exit detected.");
                        
                    } while (!userResponse.equals("exit"));
                        System.exit(0);
                    
                case "remove items":
                case "remove":
                    
                    do  {
                        //view customer cart
                        if (customerCartArray.isEmpty()) {
                            System.out.println("Error: Current cart is empty.");
                        }
                        
                        System.out.println("\nPlease input the name of the item you'd like to remove, or input \"back\" to return:\n");
                        userResponse = customerResponse.nextLine();
                    
                        if (userResponse.equalsIgnoreCase("back")) {
                            System.out.println("Going back to menu...");
                            //repeat = true;
                            mainCustomerScreen();
                            break;
                        }
                        
                        boolean foundItem = false;
                        for (Item x : customerCartArray) {
                            if (x.getItemName().equalsIgnoreCase(userResponse)) {
                                System.out.println("\nFound Item!");
                                customerCartArray.remove(x);
                                System.out.println(x.getItemName() +" removed from cart.");

                                foundItem = true;
                                //view customer cart
                                System.out.println("-------------------------------------------------------------------------------\n" 
                                    + "Current user cart:");
                                for (int i = 0; i < customerCartArray.size(); i++) {
                                    System.out.println(customerCartArray.get(i).getItemName());
                                }
                                break;
                            }
                            
                            //view customer cart
                            System.out.println("-------------------------------------------------------------------------------\n" 
                                + "Current user cart:");
                            for (int i = 0; i < customerCartArray.size(); i++) {
                                System.out.println(customerCartArray.get(i).getItemName());
                            }
                        
                        }
                        if (!foundItem) 
                            System.out.println("Item not found or exit detected.");
                        
                    } while (!userResponse.equals("exit"));
                    System.exit(0);
                    
                    
                case "View cart":
                case "view cart":
                case "View":
                case "view":
                case "Cart":
                case "cart":
                    
                    do {
                        //check for empty customer cart
                        if (customerCartArray.isEmpty()) {
                            System.out.println("Error: Current cart is empty.");
                        }
                        else {
                            System.out.println("-------------------------------------------------------------------------------\n" 
                                + "Here's what you have in your cart:");
                                    for (int i = 0; i < customerCartArray.size(); i++) {
                                        System.out.println(customerCartArray.get(i).getItemName());
                                    }
                        }
                    
                        System.out.println("\nPlease input \"back\" to return:\n");
                        userResponse = customerResponse.nextLine();
                        
                        if (userResponse.equalsIgnoreCase("back")) {
                            System.out.println("Going back to menu...");
                            mainCustomerScreen();
                            break;
                        }
                    
                    } while (!userResponse.equals("exit"));
                    System.exit(0);
                    
                case "checkout":
                case "Checkout":
                    double checkoutTotal = 0.00;
                    do  {
                        //check for empty customer cart
                        if (customerCartArray.isEmpty()) {
                            System.out.println("Error: Current cart is empty.");
                        }
                        
                        //view customer cart
                        System.out.println("-------------------------------------------------------------------------------\n" 
                            + "Current user cart:");
                        for (int i = 0; i < customerCartArray.size(); i++) {
                            System.out.println(customerCartArray.get(i).getItemName());
                        }
                        for (int i = 0; i < customerCartArray.size(); i++) {
                            checkoutTotal += (customerCartArray.get(i).getPrice());
                        }
                        
                        System.out.printf("Proceed to checkout with total of $%.2f?\n", checkoutTotal);
                        userResponse = customerResponse.nextLine();
                        
                        if (userResponse.equalsIgnoreCase("no")) {
                            System.out.println("Going back to menu...");
                            mainCustomerScreen();
                            break;
                        } else if (userResponse.equalsIgnoreCase("yes")) {
                            System.out.println("\nItem(s) purchased. Have a nice day!");
                            System.exit(0);
                        }
                        
                        
                        
                    } while (!userResponse.equals("exit"));
                    
                    repeat = false;
                    break;
                    
                case "exit":
                case "Exit":
                case "EXIT":
                    System.out.println("Have a nice day!");
                    System.exit(0);
                    
                default: 
                    System.out.println("Invalid response: Please specify one of the above options or type \'exit\'");
                    repeat = true;
                    break;
            }
        }
        customerResponse.close();
        }
    }
    
    
    
}
